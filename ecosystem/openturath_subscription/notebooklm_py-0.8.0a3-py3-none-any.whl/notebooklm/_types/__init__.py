"""Private type implementation package."""
